const help = (prefix) => {
	return `
「 *B R Y A N B O T* 」

◪ *INFO*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Creator: BryanRafly
  ❏ https://instagram.com/bryan_rafly09
  ❏ https://t.me/bryan_rafly
  ❏ wa.me/6289649480997
  


  *TERIMAKASIH KEPADA*
  ❏ *RADYA*
  ❏ *FARID*
  ❏ *M.HADI.FIRMANSYAH*
  ❏ *NAZWAS*
 


  *MYBOT TEAM*
  ❏ *FADHIL GRAPHY*
  ❏ *ANANG*
  ❏ *AFFIS*
  ❏ *BRYAN*
  ❏ *XPTN*
  ❏ *RIZKY
  


  *FRIENDS OWNER*
   ❏ https://instagram.com/chell_projets


  
◪ *ABOUT*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bugreport



◪ *MAKER*
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}stickergif
  ├─ ❏ ${prefix}toimg
  ├─ ❏ ${prefix}tomp3
  ├─ ❏ ${prefix}bpink
  ├─ ❏ ${prefix}marvellogo
  ├─ ❏ ${prefix}snowwrite
  ├─ ❏ ${prefix}3dtext
  ├─ ❏ ${prefix}ninjalogo
  ├─ ❏ ${prefix}water
  ├─ ❏ ${prefix}firetext
  ├─ ❏ ${prefix}logowolf
  ├─ ❏ ${prefix}logowolf2
  ├─ ❏ ${prefix}phlogo
  ├─ ❏ ${prefix}glitch
  ├─ ❏ ${prefix}neonlogo
  ├─ ❏ ${prefix}neonlogo2
  ├─ ❏ ${prefix}lionlogo
  ├─ ❏ ${prefix}jokerlogo
  ├─ ❏ ${prefix}shadow
  ├─ ❏ ${prefix}burnpaper
  ├─ ❏ ${prefix}coffee
  ├─ ❏ ${prefix}lovepaper
  ├─ ❏ ${prefix}woodblock
  ├─ ❏ ${prefix}qowheart
  ├─ ❏ ${prefix}mutgrass
  ├─ ❏ ${prefix}undergocean
  ├─ ❏ ${prefix}woodenboards
  ├─ ❏ ${prefix}wolfmetal
  ├─ ❏ ${prefix}metalictglow
  ├─ ❏ ${prefix}8bit
  ├─ ❏ ${prefix}ttp
  ├─ ❏ ${prefix}herrypotter
  ├─ ❏ ${prefix}pubglogo
  └─ ❏ ${prefix}quotemaker



◪ *MEDIA*
  │
  ├─ ❏ ${prefix}trendtwit
  ├─ ❏ ${prefix}randomkpop
  └─ ❏ ${prefix}ytsearch



◪ *EDUCATION*
  │
  ├─ ❏ ${prefix}wiki
  ├─ ❏ ${prefix}wikien
  ├─ ❏ ${prefix}nulis
  ├─ ❏ ${prefix}quotes
  ├─ ❏ ${prefix}quotes2
  └─ ❏ ${prefix}artinama



◪ *KERANG AJAIB*
  │
  ├─ ❏ ${prefix}apakah
  ├─ ❏ ${prefix}kapankah
  ├─ ❏ ${prefix}rate
  └─ ❏ ${prefix}bisakah



◪ *DOWNLOADER*
  │
  ├─ ❏ ${prefix}pinterest
  ├─ ❏ ${prefix}ytmp3
  ├─ ❏ ${prefix}ytmp4
  ├─ ❏ ${prefix}tiktok
  └─ ❏ ${prefix}joox



◪ *MEME*
  │
  ├─ ❏ ${prefix}meme
  └─ ❏ ${prefix}memeindo



◪ *GROUP*
  │
  ├─ ❏ ${prefix}opengc
  ├─ ❏ ${prefix}closegc
  ├─ ❏ ${prefix}promote
  ├─ ❏ ${prefix}demote
  ├─ ❏ ${prefix}tagall
  ├─ ❏ ${prefix}tagall2
  ├─ ❏ ${prefix}tagall3
  ├─ ❏ ${prefix}tagall4
  ├─ ❏ ${prefix}tagall5
  ├─ ❏ ${prefix}add
  ├─ ❏ ${prefix}kick
  ├─ ❏ ${prefix}listadmins
  ├─ ❏ ${prefix}linkgroup
  ├─ ❏ ${prefix}leave
  ├─ ❏ ${prefix}welcome
  ├─ ❏ ${prefix}nsfw
  ├─ ❏ ${prefix}leveling
  ├─ ❏ ${prefix}level
  ├─ ❏ ${prefix}delete
  ├─ ❏ ${prefix}simih
  └─ ❏ ${prefix}ownergroup



◪ *SOUND*
  │
  ├─ ❏ ${prefix}play
  └─ ❏ ${prefix}tts



◪ *MUSIC*
  │
  ├─ ❏ ${prefix}lirik
  └─ ❏ ${prefix}chord



◪ *ISLAM*
  │
  └─ ❏ ${prefix}quran



◪ *STALK*
  │
  ├─ ❏ ${prefix}tiktokstalk
  └─ ❏ ${prefix}igstalk



◪ *WIBU*
  │
  ├─ ❏ ${prefix}neonime
  ├─ ❏ ${prefix}pokemon
  ├─ ❏ ${prefix}loli
  ├─ ❏ ${prefix}waifu
  ├─ ❏ ${prefix}randomanime
  ├─ ❏ ${prefix}husbu
  ├─ ❏ ${prefix}husbu2
  ├─ ❏ ${prefix}wait
  └─ ❏ ${prefix}nekonime



◪ *18+*
  |
  ├─ ❏ ${prefix}randomhentai
  ├─ ❏ ${prefix}nsfwtrap
  └─ ❏ ${prefix}nsfwneko



◪ *FUN*
  │
  ├─ ❏ ${prefix}alay
  ├─ ❏ ${prefix}gantengcek
  ├─ ❏ ${prefix}watak
  ├─ ❏ ${prefix}hobby
  ├─ ❏ ${prefix}game
  ├─ ❏ ${prefix}bucin
  ├─ ❏ ${prefix}trust
  ├─ ❏ ${prefix}dare
  └─ ❏ ${prefix}simi



◪ *INFORMATION*
  │
  ├─ ❏ ${prefix}bahasa
  ├─ ❏ ${prefix}kodenegara
  ├─ ❏ ${prefix}kbbi
  ├─ ❏ ${prefix}fakta
  ├─ ❏ ${prefix}infocuaca
  ├─ ❏ ${prefix}infogempa
  ├─ ❏ ${prefix}jadwaltvnow
  └─ ❏ ${prefix}covid



◪ *OWNER*
  │
  ├─ ❏ ${prefix}setprefix
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}bcgc
  ├─ ❏ ${prefix}clone
  └─ ❏ ${prefix}clearall



◪ *OTHER*
  │
  ├─ ❏ ${prefix}send
  ├─ ❏ ${prefix}wame
  ├─ ❏ ${prefix}virtex
  ├─ ❏ ${prefix}exe
  ├─ ❏ ${prefix}qrcode
  ├─ ❏ ${prefix}afk
  ├─ ❏ ${prefix}timer
  ├─ ❏ ${prefix}fml
  └─ ❏ ${prefix}fml2

 YUK DONASI UNTUK MEMBANTU OWNER MENGEMBANGKAN PROJESCT BOT WHATSAPP INI DENGAN CARA DONASI KE

 PULSA : 087724880504
 DANA : 087724880504

 TERIMAKASIH  YANG ELAH BERDONASI SEMOA BOT TERUS BERKEMBANG DAN TERUS BERJALAN DNGN BAIK

 ~BryanRafly

◪ *BryanRafly*
`
}

exports.help = help
